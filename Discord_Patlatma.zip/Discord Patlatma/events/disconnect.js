module.exports = client => {
  console.log(`Bağlantın koptu Reis! ${new Date()}`);
};